import React, { createContext, useState, useEffect, useCallback } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem('scholarshipUser');
      if (storedUser) {
        const parsedUser = JSON.parse(storedUser);
        // Ensure isVip exists, default to false if not
        setUser({ ...parsedUser, isVip: parsedUser.isVip || false });
      }
    } catch (error) {
      console.error("Failed to parse user from localStorage", error);
      localStorage.removeItem('scholarshipUser');
    } finally {
      setLoading(false);
    }
  }, []);

  const login = useCallback((userData) => {
    // Ensure isVip exists on login, default to false
    const userWithVipStatus = { ...userData, isVip: userData.isVip || false };
    localStorage.setItem('scholarshipUser', JSON.stringify(userWithVipStatus));
    setUser(userWithVipStatus);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('scholarshipUser');
    setUser(null);
  }, []);

  const updateUser = useCallback((updatedData) => {
    setUser(prevUser => {
      if (!prevUser) return null;
      const newUser = { ...prevUser, ...updatedData };
      localStorage.setItem('scholarshipUser', JSON.stringify(newUser));
      return newUser;
    });
  }, []);

  const value = {
    user,
    isAuthenticated: !!user,
    isLoading: loading,
    login,
    logout,
    updateUser, // Expose updateUser
  };

  return <AuthContext.Provider value={value}>{!loading && children}</AuthContext.Provider>;
};

export default AuthContext;